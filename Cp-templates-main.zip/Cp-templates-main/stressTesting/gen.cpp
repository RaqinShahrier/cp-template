#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
 
#define int long long


#define vi vector<int>
#define vvi vector<vi>
#define vll vector<ll>
#define vvll vector<vll>
#define pi pair<int,int>
#define pll pair<ll,ll>
#define ff first
#define ss second
#define vpi vector<pair<int,int>>
#define rep(ii,st, n) for(int ii=st; ii<n; ii++)
#define gp " "




int ran(int lo, int hi){
    return lo + rand()%(hi-lo+1);
}

void solve(int testcases){
    cout<<1<<endl;
    int n;
    n = 1000000;
    

}

int32_t main(){
    srand(time(0));

    solve(1);

    return 0;
}
